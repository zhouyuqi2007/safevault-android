# 安全文件保险箱（Android 项目）

这是 Android Studio 工程源码，不是已经编译好的 APK。

## 功能
- Android 系统文件选择器导入和保存文件
- AES-256-GCM 分块认证加密
- PBKDF2-HMAC-SHA256（600,000 次迭代）
- 每个文件独立随机 salt 和 nonce 前缀
- 认证结束记录，可检测篡改、截断及尾随数据
- 不申请广泛存储权限，不联网，不上传文件
- 原文件不删除
- 先在应用私有缓存完成加/解密，解密认证成功后才复制明文到用户目标
- 需要额外临时空间，空间不足时操作会失败

## 构建 APK
1. 电脑安装 Android Studio（建议稳定版）及 Android SDK Platform 35。
2. 解压整个 SafeVaultAndroid 文件夹。
3. Android Studio 选择 Open，打开该文件夹。
4. 等待 Gradle 同步；如提示安装 Android Gradle Plugin/SDK，按提示安装。
5. 菜单 Build -> Build Bundle(s) / APK(s) -> Build APK(s)。
6. APK 通常位于 `app/build/outputs/apk/debug/app-debug.apk`。

## 重要安全说明
- 请先用非重要文件测试加密和解密，再处理重要数据。
- 密码至少 8 个字符；建议使用更长的独特密码。
- 忘记密码无法恢复数据。
- 目前输出直接写入系统文件选择器选定的目标。如果进程或设备在写入期间异常中断，目标文件可能是不完整的；请删除该未完成输出并重新操作。
- 此工程未经过 Android 真机兼容性/安全审计，不应宣称为经过认证的安全产品。
- 临时缓存文件会在正常流程结束时删除；应用尽力覆盖临时明文，但闪存设备不保证物理安全擦除。
- 本工程的加密文件格式 SAFEENC1 与之前的 Python 脚本格式并不相同，不能直接互相解密。
