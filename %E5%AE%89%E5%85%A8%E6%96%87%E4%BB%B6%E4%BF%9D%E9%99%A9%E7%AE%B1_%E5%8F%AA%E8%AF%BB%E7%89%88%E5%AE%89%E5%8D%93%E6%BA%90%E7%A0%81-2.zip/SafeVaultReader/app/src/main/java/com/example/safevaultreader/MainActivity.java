package com.example.safevaultreader;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int REQ_INPUT = 10, REQ_OUTPUT = 12;
    private Uri inputUri;
    private EditText password;
    private TextView inputLabel, status;
    private ProgressBar progress;
    private Button decryptButton;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();

    @Override public void onCreate(Bundle state) { super.onCreate(state); buildUi(); }
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private LinearLayout.LayoutParams lp() { return new LinearLayout.LayoutParams(-1, -2); }
    private TextView text(String s, int size, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); return t;
    }
    private Button button(String s) { Button b = new Button(this); b.setText(s); b.setAllCaps(false); return b; }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(22), dp(28), dp(22), dp(24)); page.setBackgroundColor(Color.rgb(246,248,252));
        TextView title = text("安全文件保险箱 · 只读版", 25, Color.rgb(20,35,65));
        title.setGravity(Gravity.CENTER); title.setTypeface(null, 1); page.addView(title, lp());
        TextView sub = text("仅用于解密主控版生成的 .enc 文件", 14, Color.rgb(85,101,125));
        sub.setGravity(Gravity.CENTER); LinearLayout.LayoutParams slp=lp(); slp.bottomMargin=dp(26); page.addView(sub,slp);
        Button choose=button("选择加密文件（.enc）"); page.addView(choose,lp()); choose.setOnClickListener(v->chooseInput());
        inputLabel=text("尚未选择文件",14,Color.DKGRAY); LinearLayout.LayoutParams flp=lp(); flp.topMargin=dp(12); flp.bottomMargin=dp(18); page.addView(inputLabel,flp);
        password=new EditText(this); password.setSingleLine(true); password.setHint("输入你收到的解密密码"); password.setInputType(129); page.addView(password,lp());
        decryptButton=button("验证并解密 → 保存文件"); LinearLayout.LayoutParams dlp=lp(); dlp.topMargin=dp(18); page.addView(decryptButton,dlp); decryptButton.setOnClickListener(v->startDecrypt());
        progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal); progress.setIndeterminate(true); progress.setVisibility(View.GONE); LinearLayout.LayoutParams plp=lp(); plp.topMargin=dp(20); page.addView(progress,plp);
        status=text("本应用不提供加密功能。原加密文件不会被删除；密码错误或文件损坏时不会输出解密文件。忘记密码无法恢复。",13,Color.rgb(75,88,110)); LinearLayout.LayoutParams st=lp(); st.topMargin=dp(14); page.addView(status,st);
        TextView foot=text("文件在本机处理，不上传服务器。请通过独立渠道接收密码。",12,Color.GRAY); LinearLayout.LayoutParams fp=lp(); fp.topMargin=dp(22); page.addView(foot,fp);
        scroll.addView(page); setContentView(scroll);
    }
    private void chooseInput() {
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("*/*");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION); startActivityForResult(i,REQ_INPUT);
    }
    private void startDecrypt() {
        if(inputUri==null){message("请先选择加密文件。");return;}
        String p=password.getText().toString(); if(p.length()<8){message("密码至少需要 8 个字符。");return;}
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("application/octet-stream");
        i.putExtra(Intent.EXTRA_TITLE,"decrypted_file"); startActivityForResult(i,REQ_OUTPUT);
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        super.onActivityResult(requestCode,resultCode,data); if(resultCode!=RESULT_OK||data==null||data.getData()==null)return;
        Uri uri=data.getData(); if(requestCode==REQ_INPUT){inputUri=uri;inputLabel.setText("已选择："+uri.getLastPathSegment());return;}
        if(requestCode==REQ_OUTPUT){setBusy(true,"正在解密并验证，请保持应用打开……");String secret=password.getText().toString();Uri source=inputUri;
            worker.execute(()->{java.io.File staged=null;boolean opened=false;try{
                staged=java.io.File.createTempFile("safevault-reader-",".stage",getCacheDir());
                try(InputStream in=getContentResolver().openInputStream(source);OutputStream out=new java.io.FileOutputStream(staged)){
                    if(in==null)throw new IllegalStateException("无法读取所选文件。"); CryptoEngine.decrypt(in,out,secret);out.flush();}
                try(InputStream in=new java.io.FileInputStream(staged);OutputStream out=getContentResolver().openOutputStream(uri,"wt")){
                    if(out==null)throw new IllegalStateException("无法写入目标文件。");opened=true;byte[] buf=new byte[1024*1024];int n;while((n=in.read(buf))!=-1)out.write(buf,0,n);out.flush();}
                runOnUiThread(()->setBusy(false,"解密成功，完整性验证通过。"));
            }catch(Exception e){if(opened)try{android.provider.DocumentsContract.deleteDocument(getContentResolver(),uri);}catch(Exception ignored){}String m=e.getMessage()==null?"密码错误或文件无法处理":e.getMessage();runOnUiThread(()->setBusy(false,"解密失败："+m));
            }finally{if(staged!=null&&staged.exists()){try(java.io.RandomAccessFile raf=new java.io.RandomAccessFile(staged,"rw")){byte[] z=new byte[65536];long left=raf.length();raf.seek(0);while(left>0){int n=(int)Math.min(left,z.length);raf.write(z,0,n);left-=n;}raf.getFD().sync();}catch(Exception ignored){}staged.delete();}}});}
    }
    private void setBusy(boolean busy,String msg){progress.setVisibility(busy?View.VISIBLE:View.GONE);decryptButton.setEnabled(!busy);status.setText(msg);}
    private void message(String s){new AlertDialog.Builder(this).setMessage(s).setPositiveButton("知道了",null).show();}
    @Override protected void onDestroy(){super.onDestroy();worker.shutdown();}
}
