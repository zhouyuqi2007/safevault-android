package com.example.safevault;

import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.SecureRandom;
import java.util.Arrays;

import javax.crypto.AEADBadTagException;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

final class CryptoEngine {
    private static final byte[] MAGIC = "SAFEENC1".getBytes(StandardCharsets.US_ASCII);
    private static final int SALT_LEN = 16;
    private static final int PREFIX_LEN = 8;
    private static final int HEADER_LEN = 8 + 16 + 8 + 4;
    private static final int TAG_LEN = 16;
    private static final int CHUNK = 4 * 1024 * 1024;
    private static final int ITERATIONS = 600_000;
    private static final int DATA = 1;
    private static final int FINAL = 2;

    private CryptoEngine() {}

    static void encrypt(InputStream in, OutputStream out, String password)
            throws Exception {
        byte[] salt = randomBytes(SALT_LEN);
        byte[] prefix = randomBytes(PREFIX_LEN);
        byte[] header = ByteBuffer.allocate(HEADER_LEN).order(ByteOrder.BIG_ENDIAN)
                .put(MAGIC).put(salt).put(prefix).putInt(CHUNK).array();
        SecretKey key = derive(password, salt);
        out.write(header);

        byte[] buffer = new byte[CHUNK];
        long counter = 0;
        int n;
        while ((n = readChunk(in, buffer)) > 0) {
            if (counter > 0xFFFFFFFFL) throw new IOException("文件包含过多数据块。");
            byte[] aad = aad(header, DATA, n, counter);
            byte[] encrypted = crypt(Cipher.ENCRYPT_MODE, key, nonce(prefix, counter), aad,
                    Arrays.copyOf(buffer, n));
            writeInt(out, DATA);
            writeInt(out, n);
            out.write(encrypted);
            counter++;
        }
        byte[] finalTag = crypt(Cipher.ENCRYPT_MODE, key, nonce(prefix, counter),
                aad(header, FINAL, 0, counter), new byte[0]);
        writeInt(out, FINAL);
        writeInt(out, 0);
        out.write(finalTag);
        Arrays.fill(buffer, (byte) 0);
    }

    static void decrypt(InputStream in, OutputStream out, String password)
            throws Exception {
        byte[] header = readExact(in, HEADER_LEN);
        ByteBuffer h = ByteBuffer.wrap(header).order(ByteOrder.BIG_ENDIAN);
        byte[] magic = new byte[8], salt = new byte[SALT_LEN], prefix = new byte[PREFIX_LEN];
        h.get(magic).get(salt).get(prefix);
        int chunkSize = h.getInt();
        if (!Arrays.equals(magic, MAGIC)) throw new IOException("文件格式不正确。");
        if (chunkSize < 64 * 1024 || chunkSize > 64 * 1024 * 1024)
            throw new IOException("文件分块参数无效。");

        SecretKey key = derive(password, salt);
        long counter = 0;
        while (true) {
            int type = readInt(in);
            int length = readInt(in);
            if (type == DATA) {
                if (length < 1 || length > chunkSize) throw new IOException("数据块长度无效。");
                byte[] encrypted = readExact(in, length + TAG_LEN);
                try {
                    byte[] plain = crypt(Cipher.DECRYPT_MODE, key, nonce(prefix, counter),
                            aad(header, DATA, length, counter), encrypted);
                    if (plain.length != length) throw new IOException("数据块长度校验失败。");
                    out.write(plain);
                    Arrays.fill(plain, (byte) 0);
                } catch (AEADBadTagException ex) {
                    throw new GeneralSecurityException("密码错误，或文件已被修改/损坏。", ex);
                }
                counter++;
                if (counter > 0xFFFFFFFFL) throw new IOException("数据块数量超出格式限制。");
            } else if (type == FINAL) {
                if (length != 0) throw new IOException("结束标记无效。");
                byte[] tag = readExact(in, TAG_LEN);
                try {
                    crypt(Cipher.DECRYPT_MODE, key, nonce(prefix, counter),
                            aad(header, FINAL, 0, counter), tag);
                } catch (AEADBadTagException ex) {
                    throw new GeneralSecurityException("密码错误，或文件已被修改/截断。", ex);
                }
                if (in.read() != -1) throw new IOException("结束标记后存在多余数据。");
                return;
            } else {
                throw new IOException("未知文件记录类型。");
            }
        }
    }

    private static SecretKey derive(String password, byte[] salt) throws Exception {
        if (password == null || password.length() < 8) throw new GeneralSecurityException("密码至少需要 8 个字符。");
        char[] chars = password.toCharArray();
        PBEKeySpec spec = new PBEKeySpec(chars, salt, ITERATIONS, 256);
        Arrays.fill(chars, '\0');
        try {
            byte[] encoded = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
                    .generateSecret(spec).getEncoded();
            try { return new SecretKeySpec(encoded, "AES"); }
            finally { Arrays.fill(encoded, (byte) 0); }
        } finally {
            spec.clearPassword();
        }
    }

    private static byte[] crypt(int mode, SecretKey key, byte[] nonce, byte[] aad, byte[] data)
            throws GeneralSecurityException {
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(mode, key, new GCMParameterSpec(128, nonce));
        cipher.updateAAD(aad);
        return cipher.doFinal(data);
    }

    private static byte[] nonce(byte[] prefix, long counter) {
        return ByteBuffer.allocate(12).order(ByteOrder.BIG_ENDIAN)
                .put(prefix).putInt((int) counter).array();
    }

    private static byte[] aad(byte[] header, int type, int length, long counter) {
        return ByteBuffer.allocate(header.length + 1 + 4 + 4).order(ByteOrder.BIG_ENDIAN)
                .put(header).put((byte) type).putInt(length).putInt((int) counter).array();
    }

    private static byte[] randomBytes(int n) {
        byte[] b = new byte[n];
        new SecureRandom().nextBytes(b);
        return b;
    }

    private static int readChunk(InputStream in, byte[] buffer) throws IOException {
        int total = 0;
        while (total < buffer.length) {
            int n = in.read(buffer, total, buffer.length - total);
            if (n < 0) break;
            if (n == 0) continue;
            total += n;
        }
        return total;
    }

    private static byte[] readExact(InputStream in, int n) throws IOException {
        byte[] b = new byte[n];
        int offset = 0;
        while (offset < n) {
            int got = in.read(b, offset, n - offset);
            if (got < 0) throw new EOFException("文件不完整或已被截断。");
            offset += got;
        }
        return b;
    }

    private static int readInt(InputStream in) throws IOException {
        byte[] b = readExact(in, 4);
        return ByteBuffer.wrap(b).order(ByteOrder.BIG_ENDIAN).getInt();
    }

    private static void writeInt(OutputStream out, int v) throws IOException {
        out.write(ByteBuffer.allocate(4).order(ByteOrder.BIG_ENDIAN).putInt(v).array());
    }
}
