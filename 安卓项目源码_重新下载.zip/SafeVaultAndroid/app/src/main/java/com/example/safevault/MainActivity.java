package com.example.safevault;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.InputStream;
import java.io.OutputStream;
import java.security.GeneralSecurityException;
import java.security.SecureRandom;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int REQ_INPUT = 10;
    private static final int REQ_OUTPUT_ENCRYPT = 11;
    private static final int REQ_OUTPUT_DECRYPT = 12;

    private Uri inputUri;
    private EditText password;
    private EditText passwordAgain;
    private TextView inputLabel;
    private TextView status;
    private ProgressBar progress;
    private Button encryptButton, decryptButton;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        buildUi();
    }

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView text(String value, int size, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        return t;
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(22), dp(28), dp(22), dp(24));
        page.setBackgroundColor(Color.rgb(246, 248, 252));

        TextView title = text("安全文件保险箱", 27, Color.rgb(20, 35, 65));
        title.setGravity(Gravity.CENTER);
        title.setTypeface(null, 1);
        page.addView(title, matchWrap());

        TextView subtitle = text("AES-256-GCM · 本地加密 · 文件不上传", 13, Color.rgb(85, 101, 125));
        subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams subLp = matchWrap();
        subLp.bottomMargin = dp(24);
        page.addView(subtitle, subLp);

        Button choose = button("选择要处理的文件");
        page.addView(choose, matchWrap());
        choose.setOnClickListener(v -> chooseInput());
        inputLabel = text("尚未选择文件", 14, Color.DKGRAY);
        LinearLayout.LayoutParams fileLp = matchWrap();
        fileLp.topMargin = dp(10);
        fileLp.bottomMargin = dp(18);
        page.addView(inputLabel, fileLp);

        password = new EditText(this);
        password.setSingleLine(true);
        password.setHint("输入密码（至少 8 个字符）");
        password.setInputType(129);
        page.addView(password, matchWrap());

        passwordAgain = new EditText(this);
        passwordAgain.setSingleLine(true);
        passwordAgain.setHint("再次输入密码（仅加密时需要）");
        passwordAgain.setInputType(129);
        LinearLayout.LayoutParams passLp = matchWrap();
        passLp.topMargin = dp(8);
        passLp.bottomMargin = dp(18);
        page.addView(passwordAgain, passLp);

        encryptButton = button("加密文件  →  保存为 .enc");
        page.addView(encryptButton, matchWrap());
        encryptButton.setOnClickListener(v -> startOperation(true));

        decryptButton = button("解密文件  →  保存解密副本");
        LinearLayout.LayoutParams decLp = matchWrap();
        decLp.topMargin = dp(10);
        page.addView(decryptButton, decLp);
        decryptButton.setOnClickListener(v -> startOperation(false));

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setIndeterminate(true);
        progress.setVisibility(View.GONE);
        LinearLayout.LayoutParams progLp = matchWrap();
        progLp.topMargin = dp(20);
        page.addView(progress, progLp);

        status = text("提示：原文件不会被删除。请妥善保管密码，忘记密码无法恢复。", 13, Color.rgb(75, 88, 110));
        LinearLayout.LayoutParams statusLp = matchWrap();
        statusLp.topMargin = dp(14);
        page.addView(status, statusLp);

        TextView footer = text("使用 Android 系统文件选择器读写文件；应用不申请照片、媒体或存储目录的广泛访问权限。", 12, Color.GRAY);
        LinearLayout.LayoutParams footLp = matchWrap();
        footLp.topMargin = dp(24);
        page.addView(footer, footLp);

        scroll.addView(page);
        setContentView(scroll);
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(-1, -2);
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        return b;
    }

    private void chooseInput() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i, REQ_INPUT);
    }

    private void startOperation(boolean encrypt) {
        if (inputUri == null) {
            message("请先选择一个文件。");
            return;
        }
        String p = password.getText().toString();
        if (p.length() < 8) {
            message("密码至少需要 8 个字符。建议使用较长且独特的密码。");
            return;
        }
        if (encrypt && !p.equals(passwordAgain.getText().toString())) {
            message("两次输入的密码不一致。");
            return;
        }
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/octet-stream");
        i.putExtra(Intent.EXTRA_TITLE, encrypt ? "encrypted_file.enc" : "decrypted_file");
        startActivityForResult(i, encrypt ? REQ_OUTPUT_ENCRYPT : REQ_OUTPUT_DECRYPT);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (requestCode == REQ_INPUT) {
            inputUri = uri;
            inputLabel.setText("已选择：" + uri.getLastPathSegment());
            return;
        }
        if (requestCode == REQ_OUTPUT_ENCRYPT || requestCode == REQ_OUTPUT_DECRYPT) {
            boolean encrypt = requestCode == REQ_OUTPUT_ENCRYPT;
            setBusy(true, encrypt ? "正在加密，请保持应用打开……" : "正在解密并验证，请保持应用打开……");
            String secret = password.getText().toString();
            worker.execute(() -> {
                java.io.File staged = null;
                boolean destinationOpened = false;
                try {
                    // 先在应用私有缓存中完成整个加/解密过程；解密必须先通过最终认证，
                    // 才把明文复制到用户选择的目标，避免认证失败时留下部分明文文件。
                    staged = java.io.File.createTempFile("safevault-", ".stage", getCacheDir());
                    try (InputStream in = getContentResolver().openInputStream(inputUri);
                         OutputStream stagedOut = new java.io.FileOutputStream(staged)) {
                        if (in == null) throw new IllegalStateException("无法读取所选文件。");
                        if (encrypt) CryptoEngine.encrypt(in, stagedOut, secret);
                        else CryptoEngine.decrypt(in, stagedOut, secret);
                        stagedOut.flush();
                    }

                    try (InputStream stagedIn = new java.io.FileInputStream(staged);
                         OutputStream out = getContentResolver().openOutputStream(uri, "wt")) {
                        if (out == null) throw new IllegalStateException("无法写入目标文件。");
                        destinationOpened = true;
                        byte[] copyBuffer = new byte[1024 * 1024];
                        int count;
                        while ((count = stagedIn.read(copyBuffer)) != -1) out.write(copyBuffer, 0, count);
                        out.flush();
                    }
                    runOnUiThread(() -> setBusy(false, encrypt ? "加密成功。原文件未删除。" : "解密成功，完整性验证通过。"));
                } catch (Exception e) {
                    if (destinationOpened) {
                        try {
                            android.provider.DocumentsContract.deleteDocument(getContentResolver(), uri);
                        } catch (Exception ignored) { }
                    }
                    String msg = safeMessage(e);
                    runOnUiThread(() -> setBusy(false, "操作失败：" + msg + "\n请检查密码、文件和保存位置。"));
                } finally {
                    if (staged != null && staged.exists()) {
                        // 尽力覆盖临时明文后删除；闪存介质不保证物理安全擦除。
                        if (!encrypt) {
                            try (java.io.RandomAccessFile raf = new java.io.RandomAccessFile(staged, "rw")) {
                                byte[] zeros = new byte[64 * 1024];
                                long left = raf.length();
                                raf.seek(0);
                                while (left > 0) {
                                    int n = (int) Math.min(left, zeros.length);
                                    raf.write(zeros, 0, n);
                                    left -= n;
                                }
                                raf.getFD().sync();
                            } catch (Exception ignored) { }
                        }
                        //noinspection ResultOfMethodCallIgnored
                        staged.delete();
                    }
                }
            });
        }
    }

    private String safeMessage(Exception e) {
        String m = e.getMessage();
        if (m == null || m.trim().isEmpty()) return "文件无法处理或认证失败";
        return m;
    }

    private void setBusy(boolean busy, String message) {
        progress.setVisibility(busy ? View.VISIBLE : View.GONE);
        encryptButton.setEnabled(!busy);
        decryptButton.setEnabled(!busy);
        status.setText(message);
    }

    private void message(String s) {
        new AlertDialog.Builder(this).setMessage(s).setPositiveButton("知道了", null).show();
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        worker.shutdown();
    }
}
